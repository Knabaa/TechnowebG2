package isep.gapp.bdd;

import java.sql.DriverManager;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.Statement;

import isep.gapp.beans.copy.Competences;

public class Competencebdd {
	
	Connection connexion=null;
	
	
	public List<Competences> recupererCompetences() {
		
		List<Competences> competences = new ArrayList<Competences>();
        Statement statement = null;
        ResultSet resultat = null;
        String competence1 =null;

       
        connexion= Connexion.loadDatabase();
        try {
        	
            statement = (Statement) connexion.createStatement();

            // Ex�cution de la requ�te
            resultat = statement.executeQuery("SELECT competence1 FROM grillecompetence");

            // R�cup�ration des donn�es
            while (resultat.next()) {
                 competence1 = resultat.getString("competence1");
          
                 Competences competence = new Competences();
                 competence.setCompetence1(competence1);
                 competences.add(competence);
            }
            
            
        } catch (SQLException e) {
        } finally {
            // Fermeture de la connexion
            try {
                if (resultat != null)
                    resultat.close();
                if (statement != null)
                    statement.close();
                if (connexion != null)
                    connexion.close();
            } catch (SQLException ignore) {
            }
        }
        return competences;
	}
	
	 public void ajouterCompetence(Competences competence) {
		 connexion= Connexion.loadDatabase();
		 
	        try {
	            PreparedStatement preparedStatement = (PreparedStatement) connexion.prepareStatement("INSERT INTO grillecompetence(competence1) VALUES(?);");
	           // if (competence.getCompetence1()==null)
	            //	System.out.println("fail");
	            //System.out.println(competence.getCompetence1().toString());
	            preparedStatement.setString(1,competence.getCompetence1());
	            //System.out.println(preparedStatement.toString());
	            preparedStatement.executeUpdate();
	            
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }
	
	 //public void supprimerCompetences(Competences competence) {
	 		//loadDatabase();
	 
	 		//try {
	 			//PreparedStatement preparedStatement = (PreparedStatement) connexion.preparedStatement("DELETE INTO grillecompetence(competence1) VALUES(?);");
	 	//	preparedStatement.setString(1,competence.getCompetence1());
     //System.out.println(preparedStatement.toString());
	 	//	preparedStatement.executeUpdate();
     
 	//	} catch (SQLException e) {
 		//	e.printStackTrace();
 	//	}
 	//}
	
	/*private void loadDatabase() {
        // Chargement du driver
        try {
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException e) {
        }

        try {
            connexion = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/gapp","root", "");
        } catch (SQLException e) {
            e.printStackTrace();
        }*/
    }

