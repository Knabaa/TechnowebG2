package isep.gapp.bdd;
import java.sql.*;

public class Validate
 {
     public static boolean checkUser(String nom,String mdp) 
     {
      boolean st =false;
      try{

	 //loading drivers for mysql
         Class.forName("com.mysql.jdbc.Driver");

 	 //creating connection with the database 
         Connection con=DriverManager.getConnection
                        ("jdbc:mysql://localhost:3306/gapp","root","root");
         PreparedStatement ps =con.prepareStatement
                             ("select * from eleve where nom=? and mdp=?");
         ps.setString(1, nom);
         ps.setString(2, mdp);
         
         
         ResultSet rs =ps.executeQuery();
         st = rs.next();
        
      }catch(Exception e)
      {
          e.printStackTrace();
      }
         return st;                 
  }   
}