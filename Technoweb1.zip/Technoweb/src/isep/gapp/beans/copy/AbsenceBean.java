package isep.gapp.beans.copy;

public class AbsenceBean {
	
	private String nom;
	private String prenom;

	public String getNom() {
		return this.nom;
	}

	public String getPrenom() {
		return this.prenom;
	}


	public void setNom( String nom ) {
		this.nom = nom;
	}

	public void setPrenom( String prenom ) {
		this.prenom = prenom;
	}

}
