package isep.gapp.servlet;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class Login extends HttpServlet {
 
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        
        String nom = request.getParameter("nom");
        String mdp = request.getParameter("mdp");
      
  
        
        if(isep.gapp.bdd.Validate.checkUser(nom, mdp))
        {
            HttpSession session=request.getSession();  
            session.setAttribute("nom",nom);
            RequestDispatcher rs = request.getRequestDispatcher("Welcome");
            rs.forward(request, response);
            out.println("Succeed");
        }
        else
        {
           out.println("<font color='red'><h1>Mail ou Mot de pass invalide</h1></font>");
           RequestDispatcher rs = request.getRequestDispatcher("/WEB-INF/index.html");
           rs.include(request, response);
        }
    }  
}