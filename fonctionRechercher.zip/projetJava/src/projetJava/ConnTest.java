package projetJava;
import java.sql.*;


public class ConnTest {

	public static void testconnexion(){
		String url	= "jdbc:mysql://localhost:3306/gapp";
		String user	= "root";
		String pass = "";
		Connection connexion	= null;
		/*	Load	JDBC	Driver.	*/
		try {
						Class.forName( "com.mysql.jdbc.Driver" );
						//	Class.forName("oracle.jdbc.OracleDriver")	;
		} catch ( ClassNotFoundException e	) {
						e.printStackTrace();
		}
		try {
						connexion	= DriverManager.getConnection( url, user, pass );
						/*	Requests	to	bdd	will	be	here	*/
						
						System.out.println("Bdd	Connected");
						
		} catch ( SQLException e	) {
		e.printStackTrace();
		} finally {
						if ( connexion	!= null )
										try {
														connexion.close();
										} catch ( SQLException ignore	) {
										 ignore.printStackTrace();
										}
		}
	}

}
