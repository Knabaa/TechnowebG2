package isep.gapp.bdd;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import isep.gapp.beans.copy.eleve1;

public class rechercher {
	
	public static eleve1 search(String champs){
		String url	= "jdbc:mysql://localhost:3306/gapp";
		String user	= "root";
		String pass = "";
		Connection connexion	= null;
		/*	Load	JDBC	Driver.	*/
		try {
						Class.forName( "com.mysql.jdbc.Driver" );
						//	Class.forName("oracle.jdbc.OracleDriver")	;
		} catch ( ClassNotFoundException e	) {
						e.printStackTrace();
		}
		try {
			connexion	= DriverManager.getConnection( url, user, pass );
						/*	Requests	to	bdd	will	be	here	*/
			Statement statement	= connexion.createStatement();
			ResultSet resultat	= statement.executeQuery( "SELECT nom, prenom FROM eleve WHERE nom='"+champs+"'" );
			eleve1 utilisateur = new eleve1();
			while ( resultat.next() ) {
				
				String nom	= resultat.getString( "nom" );
				String prenom	= resultat.getString( "prenom" );
				System.out.println(nom+" "+prenom);
				/*System.out.println("Bdd connected");*/
				utilisateur.setNom(nom);
				utilisateur.setPrenom(prenom);
			
			}
			resultat.close();
			return utilisateur;
			
		} catch ( SQLException e	) {
		e.printStackTrace();
		return null;
		} finally {
			if ( connexion	!= null )
				try {
								connexion.close();
				} catch ( SQLException ignore	) {
				 ignore.printStackTrace();
				}
		}
	}

}
