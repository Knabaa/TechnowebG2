package bean;

public class eleve {

		private int id;
		private String nom;
		private String prenom;
		private String mail;
		

		public String getNom() {
			return this.nom;
		}

		public String getPrenom() {
			return this.prenom;
		}

		public void setNom( String nom ) {
			this.nom = nom;
		}

		public void setPrenom( String prenom ) {
			this.prenom = prenom;
		
		}
}


