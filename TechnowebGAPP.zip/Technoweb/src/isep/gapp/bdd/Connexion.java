package isep.gapp.bdd;

import java.sql.DriverManager;
import java.sql.SQLException;

import com.mysql.jdbc.Connection;

public class Connexion {
	


	public static Connection loadDatabase() {
        // Chargement du driver
		Connection connexion=null; 
        try {
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException e) {
        }

        try {
             connexion=(Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/gapp","root", "");
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return connexion;
}
}