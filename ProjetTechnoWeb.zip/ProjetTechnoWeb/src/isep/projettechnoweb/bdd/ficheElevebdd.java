package isep.projettechnoweb.bdd;

import java.sql.DriverManager;
import java.sql.ResultSet;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;

import isep.projettechnoweb.beans.Eleve;
import isep.projettechnoweb.beans2.Absence; 



public class ficheElevebdd {

	
	Connection connexion;
	
	public List<Eleve> recupererEleve() {
		
		List<Eleve> eleves = new ArrayList<Eleve>();
        Statement statement = null;
        ResultSet resultat = null;
        String nom= null;
        String prenom= null;
        String mail= null;

        loadDatabase();
        
        try {
            statement = (Statement) connexion.createStatement();

            // Ex�cution de la requ�te
  
         
            resultat = statement.executeQuery("SELECT nom,prenom,mail FROM eleve");
           
          
            // R�cup�ration des donn�es
            while (resultat.next()) {
            	 nom = resultat.getString("nom");
            	 prenom = resultat.getString("prenom");
            	 mail = resultat.getString("mail");
                            
                Eleve eleve = new Eleve();
                eleve.setNom(nom);
                eleve.setPrenom(prenom);
                eleve.setMail(mail);
               
                eleves.add(eleve);
            }
        }
                     
            
           catch (SQLException e) {
            } 
           finally {
                // Fermeture de la connexion
                try {
                    if (resultat != null)
                        resultat.close();
                    if (statement != null)
                        statement.close();
                    if (connexion != null)
                        connexion.close();
                } catch (SQLException ignore) {
                }
           }
              
            return eleves; 
            
	}
	
	public List<Absence> recupererAbsence() {
		
		List<Absence> absences = new ArrayList<Absence>();
        Statement statement = null;
        ResultSet resultat = null;
        String date= null;

        loadDatabase();
        
        try {
            statement = (Statement) connexion.createStatement();

            // Ex�cution de la requ�te
            resultat = statement.executeQuery("SELECT date FROM absence ");
            
          
            // R�cup�ration des donn�es
            while (resultat.next()) {
            	 date = resultat.getString("date");
                            
                Absence absence = new Absence();
                absence.setDate(date);
               
                absences.add(absence);
            }
        }
                     
            
           catch (SQLException e) {
            } 
           finally {
                // Fermeture de la connexion
                try {
                    if (resultat != null)
                        resultat.close();
                    if (statement != null)
                        statement.close();
                    if (connexion != null)
                        connexion.close();
                } catch (SQLException ignore) {
                }
           }
              
            return absences;
	}
	
	
	private java.sql.Statement setString(int i, String string) {
		// TODO Auto-generated method stub
		return null;
	}

	private void loadDatabase() {
		
        // Chargement du driver
        try {
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException e) {
        	System.out.println("erreur");
        }
        
        try {
        	String url = "jdbc:mysql://localhost:8889/GAPP";
            String utilisateur = "root";
            String motDePasse = "root";
            connexion = (Connection) DriverManager.getConnection(url,utilisateur, motDePasse);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
    }
	
		

}