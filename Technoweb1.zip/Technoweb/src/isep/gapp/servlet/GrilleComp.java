package isep.gapp.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import isep.gapp.bdd.Competencebdd;
import isep.gapp.bdd.GrilleCompetence;

public class GrilleComp extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public GrilleComp() {
       super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		GrilleCompetence grillecompetences=new GrilleCompetence();
		request.setAttribute("comp",grillecompetences.afficheGrille());
		
		this.getServletContext().getRequestDispatcher("/WEB-INF/grilledecompetence.jsp").forward(request,response);
	}

}
