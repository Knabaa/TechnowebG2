package isep.gapp.bdd;
import java.sql.*;

public class Validate


 {
     public static boolean checkUser(String nom,String mdp) 
     {
    	 Connection connexion = null;
    	 boolean st =false;
      try{
    	  connexion=Connexion.loadDatabase();
         PreparedStatement ps =connexion.prepareStatement
                             ("select * from eleve where nom=? and mdp=?");
         ps.setString(1, nom);
         ps.setString(2, mdp);
         
         
         ResultSet rs =ps.executeQuery();
         st = rs.next();
        
      }catch(Exception e)
      {
          e.printStackTrace();
      }
         return st;                 
  }   
}