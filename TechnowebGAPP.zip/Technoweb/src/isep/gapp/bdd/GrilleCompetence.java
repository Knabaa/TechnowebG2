package isep.gapp.bdd;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.Statement;

import isep.gapp.beans.copy.Grille;

public class GrilleCompetence {

	Connection connexion=null;
	
	public List<Grille> afficheGrille(){
		List<Grille> gc = new ArrayList <Grille>();
		PreparedStatement pstatement= null;
		ResultSet resultat=null;
		String competence=null;
		
		connexion= Connexion.loadDatabase();
		
		try{
			pstatement= (PreparedStatement) connexion.prepareStatement("SELECT competence1 FROM grillecompetence WHERE nom=?");
					pstatement.setString(1, "Labadi");
					resultat=pstatement.executeQuery();
					
					while(resultat.next()){
						competence=resultat.getString("competence1");
						
						Grille grille=new Grille();
						grille.setCompetence("competence");
						gc.add(grille);
					}
			}
		catch(SQLException e){
		} finally {
			try {
				if(resultat!=null)
					resultat.close();
				if(pstatement!=null)
					pstatement.close();
				if(connexion!=null)
					connexion.close();
			}
			catch(SQLException ignore){
				
			}
		}return gc;
	}
	
}
