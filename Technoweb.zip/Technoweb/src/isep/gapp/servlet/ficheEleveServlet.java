package isep.gapp.servlet;

import java.io.IOException;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;

import isep.gapp.bdd.ficheElevebdd;
import isep.gapp.beans.copy.Eleve;
import isep.gapp.beans.copy.Absence; 

public class ficheEleveServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

  
    public ficheEleveServlet() {
       super();
    }

  public void doGet( HttpServletRequest request, HttpServletResponse response ) throws ServletException, IOException{
	  
	  ficheElevebdd listeleve=new ficheElevebdd();
	  request.setAttribute("eleves",listeleve.recupererEleve());
		
		ficheElevebdd listabsence=new ficheElevebdd();
		request.setAttribute("absences",listabsence.recupererAbsence());
		
		this.getServletContext().getRequestDispatcher("/WEB-INF/ficheEleve.jsp").forward(request,response);
  }
}
  

 
  
	
	







