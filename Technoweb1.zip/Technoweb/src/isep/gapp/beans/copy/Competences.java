package isep.gapp.beans.copy;

public class Competences {
	
	private String competence1;

	public String getCompetence1() {
		return competence1;
	}

	public void setCompetence1(String competence1) {
		this.competence1 = competence1;
	}
	
	
	
}
