package com.kavi.colorgame;

public class Main {
	 public static void main(String[] args) {
	        Utils utils = new Utils();
	        utils.initGame();
	    }

}
