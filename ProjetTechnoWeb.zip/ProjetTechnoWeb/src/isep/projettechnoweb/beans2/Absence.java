package isep.projettechnoweb.beans2;

public class Absence {
	 private String nomEleve;
	 private String date;
	 
	 public void setNomEleve( String nomEleve ) {
	        this.nomEleve = nomEleve;
	    }

	 public String getNomEleve() {
	        return nomEleve;
	    }
	 
	 public void setDate( String date ) {
	        this.date = date;
	    }

	 public String getDate() {
	        return date;
	    }
	 

}
