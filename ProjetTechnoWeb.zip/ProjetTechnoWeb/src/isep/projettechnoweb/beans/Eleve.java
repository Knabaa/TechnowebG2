package isep.projettechnoweb.beans;

public class Eleve {
	
    private String nom;
    private String prenom;
    private String mail;

    public void setNom( String nom ) {
        this.nom = nom;
    }

    public String getNom() {
        return nom;
    }

    public void setPrenom( String prenom ) {
        this.prenom = prenom;
    }

    public String getPrenom() {
        return prenom;
    }
    

    public void setMail( String mail ) {
        this.mail = mail;
    }

    public String getMail() {
        return mail;
    }


		
	}

