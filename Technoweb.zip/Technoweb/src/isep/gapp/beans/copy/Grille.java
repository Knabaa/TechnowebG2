package isep.gapp.beans.copy;

public class Grille {

	private String competence;
	
	public String getCompetence(){
		return competence;
	
	}
	public void setCompetence (String competence){
		this.competence=competence;
	}
}
